from flask import Flask, render_template, request
import numpy as np
import pickle
import json
import os

app = Flask(__name__)

# Define model and column paths dynamically
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
MODEL_PATH = os.path.join(BASE_DIR, "models", "knn_model.pkl")
COLUMNS_PATH = os.path.join(BASE_DIR, "models", "columns.json")

# Load the model and column data at startup
try:
    with open(MODEL_PATH, "rb") as f:
        model = pickle.load(f)

    with open(COLUMNS_PATH, "r") as f:
        data_columns = json.load(f)["data_columns"]
except Exception as e:
    print(f"Error loading model or columns: {e}")
    exit(1)

def churn_prediction(*form_data):
    # Convert form_data to dictionary with appropriate keys
    input_dict = dict(zip(data_columns, form_data))

    # One-hot encode categorical variables
    input_array = np.zeros(len(data_columns))
    for i, col in enumerate(data_columns):
        if col in input_dict:
            try:
                input_array[i] = float(input_dict[col])  # Convert to float for numerical values
            except ValueError:
                # Handle categorical encoding
                encoded_col = f"{col}_{input_dict[col].lower().replace(' ', '_')}"
                if encoded_col in data_columns:
                    input_array[data_columns.index(encoded_col)] = 1

    output_probab = model.predict_proba([input_array])[0][1]
    return round(output_probab, 4)

@app.route("/", methods=["GET", "POST"])
def index_page():
    if request.method == "POST":
        try:
            form_data = [
                request.form.get("Tenure", type=int, default=0),
                request.form.get("Citytier", type=int, default=0),
                request.form.get("Warehousetohome", type=int, default=0),
                request.form.get("Gender", ""),
                request.form.get("Hourspendonapp", type=int, default=0),
                request.form.get("Numberofdeviceregistered", type=int, default=0),
                request.form.get("Satisfactionscore", type=int, default=0),
                request.form.get("Maritalstatus", ""),
                request.form.get("Numberofaddress", type=int, default=0),
                request.form.get("Complain", type=int, default=0),
                request.form.get("Orderamounthikefromlastyear", type=int, default=0),
                request.form.get("Couponused", type=int, default=0),
                request.form.get("Ordercount", type=int, default=0),
                request.form.get("Daysincelastorder", type=int, default=0),
                request.form.get("Cashbackamount", type=float, default=0.0),
            ]

            output_probab = churn_prediction(*form_data)
            pred = "Churn" if output_probab > 0.4 else "Not Churn"

            data = {
                "prediction": pred,
                "predict_probability": output_probab
            }

            return render_template("result.html", data=data)

        except Exception as e:
            return render_template("error.html", error=str(e))

    return render_template("index.html")

if __name__ == "__main__":
    app.run(debug=True)
